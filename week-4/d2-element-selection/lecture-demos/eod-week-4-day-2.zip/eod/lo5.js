document.addEventListener('DOMContentLoaded', () => {
  const ul = document.createElement('ul');
  document.body.prepend(ul);
  const li = document.createElement('li');
  li.setAttribute('id', 'dreamy-eyes');
  ul.appendChild(li);
});