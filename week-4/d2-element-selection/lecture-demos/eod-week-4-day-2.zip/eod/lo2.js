document.addEventListener('DOMContentLoaded', () => {
  const cloudySpans = document.querySelectorAll('.cloudy');
  console.log(cloudySpans);
});