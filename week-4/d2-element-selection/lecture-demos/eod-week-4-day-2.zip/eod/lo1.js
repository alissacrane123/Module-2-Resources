document.addEventListener('DOMContentLoaded', () => {
  const divOfInterest = document.getElementById('catch-me-if-you-can');
  console.log(divOfInterest);
});


