document.addEventListener('DOMContentLoaded',() => {
  // document.body.setAttribute('class', 'i-got-loaded');
  document.body.classList.add('i-got-loaded');
  document.body.classList.add('i-got-loaded-2');
});