const Executive = require('./executive');

class Company {
  constructor(name) {
    this.name = name;
    this.executives = { 
      engineering: null, 
      sales: null 
    }
  }

  hireExec(name, salary, dept) {
    let newExec = new Executive(name, salary, dept)
    this.executives[dept] = newExec
  }

  hireEmployees(...people) {
    people.forEach(person => {
      // find department manager
      let manager = this.executives[person.dept]
      manager.hireEmployee(person)
    })
  }

  listEmployees() {
    let employees = []

    // get array of executives
    let executives = Object.values(this.executives)

    executives.forEach(exec => {
      // add executives to employees array
      employees.push(`{ name: ${exec.name}, salary: ${exec.salary} }`)

      // grab subordinates for each exec
      let subordinates = exec.employees
      subordinates.forEach(sub => {
        // add employees 
        employees.push(`{ name: ${sub.name}, salary: ${sub.salary} }`)
      })
    })

    return employees
  }

  giveRaises(raiseAmount) {
    // get array of executives
    let executives = Object.values(this.executives)

    executives.forEach(exec => {
      exec.receiveRaise(raiseAmount * 2);
      exec.giveRaises(raiseAmount);
    })
  }

  calculateTotalSalary() {
    let total = 0
    let executives = Object.values(this.executives)

    executives.forEach(exec => {
      total += exec.salary;
      exec.employees.forEach(emp => {
        total += emp.salary
      })
    })
    return total;
  }
}

module.exports = Company 
