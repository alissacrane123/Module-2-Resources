const Company = require('./company');
const Employee = require('./employee');

// employees
let bob = new Employee('Bob', 500, 'engineering');
let sarah = new Employee('Sarah', 500, 'sales')
// console.log(bob);
// console.log(sarah);

// create company
let shmoogle = new Company('Shmoogle');
// console.log(shmoogle)

// hire executives
shmoogle.hireExec('Sally', 1000, 'engineering')
shmoogle.hireExec('Bruce', 1000, 'sales')
// console.log(shmoogle);

// // list current employees
// console.log(shmoogle.listEmployees())

// // hire bob and sarah
shmoogle.hireEmployees(bob, sarah);
// console.log(shmoogle.listEmployees())

// // // check calculate total salary
console.log(shmoogle.calculateTotalSalary())

// // // give all employees a 5000 raise
shmoogle.giveRaises(500)
console.log(shmoogle.listEmployees())
console.log(shmoogle.calculateTotalSalary())

// // // check if two employees report to same manager
// console.log(Employee.reportToSameManager(bob, sarah))

// console.log(shmoogle)