const Employee = require('./employee')

class Executive extends Employee {
  constructor(name, salary, dept) {
    super(name, salary, dept)
    this.employees = [];
  }

  hireEmployee(employee) {
    employee.assignBoss(this);
    this.employees.push(employee);
  }

  giveRaises(raiseAmount) {
    this.employees.forEach((employee) => {
      employee.receiveRaise(raiseAmount)
    });
  }
}

module.exports = Executive

